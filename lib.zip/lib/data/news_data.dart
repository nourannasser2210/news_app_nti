import 'package:news_nti/model/news_model.dart';

class NewsData {
  // ==================== SPORTS ====================

  static List<NewsModel> sports = [
    NewsModel(
      image: 'asset/football match.jpg',
      source: 'BBC Sport',
      title: 'Latest football match news and updates',
      time: '3 hours ago',
    ),
    NewsModel(
      image: 'asset/sports stadium.jpg',
      source: 'Sky Sports',
      title: 'Latest updates from the sports world',
      time: '5 hours ago',
    ),
    NewsModel(
      image: 'asset/football player.jpg',
      source: 'ESPN',
      title: 'Football players and the latest sports news',
      time: '7 hours ago',
    ),
  ];

  // ==================== POLITICS ====================

  static List<NewsModel> politics = [
    NewsModel(
      image: 'asset/politician.jpg',
      source: 'BBC News',
      title: 'Latest political news and updates',
      time: '2 hours ago',
    ),
    NewsModel(
      image: 'asset/government meeting.jpg',
      source: 'Reuters',
      title: 'Important government meeting and decisions',
      time: '4 hours ago',
    ),
    NewsModel(
      image: 'asset/parliament.jpg',
      source: 'CNN',
      title: 'Latest news from parliament',
      time: '6 hours ago',
    ),
  ];

  // ==================== HEALTH ====================

  static List<NewsModel> health = [
    NewsModel(
      image: 'asset/doctor hospital.jpg',
      source: 'BBC Health',
      title: 'Latest health and hospital news',
      time: '1 hour ago',
    ),
    NewsModel(
      image: 'asset/healthcare.jpg',
      source: 'Health News',
      title: 'New healthcare updates and information',
      time: '4 hours ago',
    ),
    NewsModel(
      image: 'asset/medical research.jpg',
      source: 'Medical News',
      title: 'Latest medical research and discoveries',
      time: '8 hours ago',
    ),
  ];

  // ==================== BUSINESS ====================

  static List<NewsModel> business = [
    NewsModel(
      image: 'asset/business meeting.jpg',
      source: 'BBC Business',
      title: 'Latest business meeting and market news',
      time: '2 hours ago',
    ),
    NewsModel(
      image: 'asset/stock market.jpg',
      source: 'Reuters',
      title: 'Latest stock market updates',
      time: '5 hours ago',
    ),
    NewsModel(
      image: 'asset/finance.jpg',
      source: 'Business News',
      title: 'Latest finance and economy news',
      time: '7 hours ago',
    ),
  ];

  // ==================== ENVIRONMENT ====================

  static List<NewsModel> environment = [
    NewsModel(
      image: 'asset/climate change.jpg',
      source: 'BBC Environment',
      title: 'Latest climate change news and updates',
      time: '2 hours ago',
    ),
    NewsModel(
      image: 'asset/environment.jpg',
      source: 'Environment News',
      title: 'Important environmental news',
      time: '5 hours ago',
    ),
    NewsModel(
      image: 'asset/forest.jpg',
      source: 'Reuters',
      title: 'Latest news about forests and nature',
      time: '9 hours ago',
    ),
  ];

  // ==================== SCIENCE ====================

  static List<NewsModel> science = [
    NewsModel(
      image: 'asset/science laboratory.jpg',
      source: 'BBC Science',
      title: 'Latest science laboratory news',
      time: '1 hour ago',
    ),
    NewsModel(
      image: 'asset/scientist.jpg',
      source: 'Science News',
      title: 'New scientific discoveries around the world',
      time: '4 hours ago',
    ),
    NewsModel(
      image: 'asset/space technology.jpg',
      source: 'National Geographic',
      title: 'Latest space and technology discoveries',
      time: '8 hours ago',
    ),
  ];

  // ==================== GET NEWS BY CATEGORY ====================

  static List<NewsModel> getNewsByCategory(String category) {
    switch (category) {
      case 'Sports':
        return sports;

      case 'Politics':
        return politics;

      case 'Health':
        return health;

      case 'Business':
        return business;

      case 'Environment':
        return environment;

      case 'Science':
        return science;

      default:
        return [];
    }
  }
}