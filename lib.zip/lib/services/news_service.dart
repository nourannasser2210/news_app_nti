import 'package:dio/dio.dart';
import 'package:news_nti/model/news_model.dart';

class NewsService {

  static const String _apiKey = 'bdba96c240114890a0d2ecd2d2e94d9e';
  static const String _baseUrl = 'https://newsapi.org/v2';

  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: _baseUrl,
      headers: {'X-Api-Key': _apiKey},
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
    ),
  );

  // NewsAPI.org الرسمي عنده categories محددة بس، والتطبيق عندنا فيه
  // Politics و Environment مش من ضمنهم، فهنحولهم لـ /everything بدل /top-headlines
  static const Map<String, String> _officialCategories = {
    'Sports': 'sports',
    'Health': 'health',
    'Business': 'business',
    'Science': 'science',
  };

  static Future<List<NewsModel>> getNewsByCategory(String category) async {
    final bool isOfficialCategory = _officialCategories.containsKey(category);

    try {
      final Response response;

      if (isOfficialCategory) {
        response = await _dio.get(
          '/top-headlines',
          queryParameters: {
            'category': _officialCategories[category],
            'country': 'us',
            'pageSize': 20,
          },
        );
      } else {
        response = await _dio.get(
          '/everything',
          queryParameters: {
            'q': category,
            'language': 'en',
            'sortBy': 'publishedAt',
            'pageSize': 20,
          },
        );
      }

      final List<dynamic> articles = response.data['articles'] ?? [];

      return articles
          .map((article) => NewsModel.fromJson(article))
          .where((news) => news.title.isNotEmpty && news.title != '[Removed]')
          .toList();
    } on DioException catch (e) {
      final message = e.response?.data is Map
          ? (e.response?.data['message'] ?? e.message)
          : e.message;
      throw Exception('فشل تحميل الأخبار: $message');
    }
  }
}