import 'package:flutter/material.dart';
import 'package:news_nti/model/item_model.dart';
import 'package:news_nti/screens/news_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    final int crossAxisCount;
    if (width >= 1100) {
      crossAxisCount = 4;
    } else if (width >= 700) {
      crossAxisCount = 3;
    } else {
      crossAxisCount = 2;
    }

    final horizontalPadding = (width * 0.06).clamp(16.0, 64.0);
    final titleFontSize = width < 400 ? 20.0 : width < 700 ? 24.0 : 28.0;
    final gridSpacing = width < 700 ? 12.0 : 18.0;

    // A taller tile on small screens prevents the card content from overflowing.
    final childAspectRatio = width < 400
        ? 0.90
        : width < 700
        ? 0.95
        : width < 1100
        ? 1.0
        : 1.08;

    final items = <ItemModel>[
      ItemModel(title: 'Sports', image: 'asset/sports.png', color: Colors.red),
      ItemModel(
        title: 'Politics',
        image: 'asset/Politics.png',
        color: Colors.deepPurpleAccent,
      ),
      ItemModel(title: 'Health', image: 'asset/health.png', color: Colors.pink),
      ItemModel(
        title: 'Business',
        image: 'asset/bussines.png',
        color: Colors.brown,
      ),
      ItemModel(
        title: 'Environment',
        image: 'asset/environment.png',
        color: Colors.green,
      ),
      ItemModel(
        title: 'Science',
        image: 'asset/science.png',
        color: Colors.yellow,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.green,
        title: const Text(
          'News',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: horizontalPadding,
            vertical: 12,
          ),
          child: Column(
            children: [
              Text(
                'Pick your category of interest',
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: titleFontSize,
                  fontWeight: FontWeight.w800,
                ),
              ),
              SizedBox(height: width < 400 ? 16 : 24),
              Expanded(
                child: GridView.builder(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.only(bottom: 8),
                  itemCount: items.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: crossAxisCount,
                    crossAxisSpacing: gridSpacing,
                    mainAxisSpacing: gridSpacing,
                    childAspectRatio: childAspectRatio,
                  ),
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => NewsScreen(category: item.title),
                          ),
                        );
                      },
                      child: CustomContainer(
                        color: item.color,
                        item: item,
                        index: index,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomContainer extends StatelessWidget {
  const CustomContainer({
    super.key,
    required this.color,
    required this.index,
    required this.item,
  });

  final Color color;
  final ItemModel item;
  final int index;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final imageHeight = width < 400 ? 44.0 : width < 700 ? 56.0 : 64.0;
    final fontSize = width < 400 ? 14.0 : 16.0;

    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(24),
          topRight: const Radius.circular(24),
          bottomRight: Radius.circular(index.isEven ? 0 : 24),
          bottomLeft: Radius.circular(index.isEven ? 24 : 0),
        ),
      ),
      padding: const EdgeInsets.all(12),
      child: Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(item.image, height: imageHeight),
              const SizedBox(height: 8),
              Text(
                item.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: fontSize,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
