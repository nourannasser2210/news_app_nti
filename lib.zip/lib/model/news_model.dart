class NewsModel {
  const NewsModel({
    required this.title,
    required this.source,
    required this.image,
    required this.time,
    this.url,
  });

  final String title;
  final String source;
  final String image;
  final String time;
  final String? url;

  factory NewsModel.fromJson(Map<String, dynamic> json) {
    return NewsModel(
      title: json['title'] ?? 'No title',
      source: json['source']?['name'] ?? 'Unknown source',
      image: json['urlToImage'] ?? '',
      time: _formatTime(json['publishedAt']),
      url: json['url'],
    );
  }

  static String _formatTime(String? isoDate) {
    if (isoDate == null) return '';
    final date = DateTime.tryParse(isoDate);
    if (date == null) return '';
    final now = DateTime.now();
    final diff = now.difference(date);

    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}