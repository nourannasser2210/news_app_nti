import 'package:flutter/material.dart';
import 'package:news_nti/screens/home_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const HomeScreen(),
    );
  }
}
// import 'package:flutter/material.dart';
// import 'package:news_nti/screens/task_screen.dart';
//
// void main() {
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: const TaskScreen(),
//     );
//   }
// // }




// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'screens/taskcubit.dart';
//
// void main() {
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: BlocProvider(
//         create: (context) => CounterCubit(),
//         child: const CounterScreen(),
//       ),
//     );
//   }
// }
//
// class CounterScreen extends StatelessWidget {
//   const CounterScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             BlocBuilder<CounterCubit, int>(
//               builder: (context, count) {
//                 return Text(
//                   '$count',
//                   style: const TextStyle(
//                     fontSize: 48,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black,
//                   ),
//                 );
//               },
//             ),
//             const SizedBox(height: 24),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 IconButton(
//                   iconSize: 40,
//                   icon: const Icon(Icons.remove_circle_outline, color: Colors.black),
//                   onPressed: () => context.read<CounterCubit>().decrement(),
//                 ),
//                 const SizedBox(width: 20),
//                 IconButton(
//                   iconSize: 40,
//                   icon: const Icon(Icons.add_circle_outline, color: Colors.black),
//                   onPressed: () => context.read<CounterCubit>().increment(),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }